let valueMovement = 0

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  rect(valueMovement,valueMovement,20,20)
  stroke(0,0,150);
  strokeWeight(2);
  fill(0,0,200);
}

function keypressed() {
  
}